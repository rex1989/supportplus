<div class="tab-pane" id="create_ticket">
	<div id="create_ticket_container" style="">
		<?php include_once( WCE_PLUGIN_DIR.'includes/create_new_ticket.php' );?>
	</div>
	<div class="wait" style="display: none;"><img alt="Please Wait" src="<?php echo WCE_PLUGIN_URL.'asset/images/ajax-loader@2x.gif';?>"></div>
</div>